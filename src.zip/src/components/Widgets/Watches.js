import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';

//watch images
import Runtime from '../../Assets/img/runtime_icon.png';
import Total from '../../Assets/img/Total_icon.png';
import Stops from '../../Assets/img/Total_icon-03.png';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

const content = {
	    padding: '0px',
	    textAlign: 'center',
		marginLeft: '35%',
		whiteSpace: 'nowrap'
}

const imageGrid = {
		padding: '5px'
};

const imageRuntime = {
		width: '65px',
		marginTop: '5%'
}

class index extends Component { 
	render() { 
		return (
				<div className="row">
				<RctCollapsibleCard
				colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4"
				reloadable
				fullBlock
				>
				 <Grid style={content} container xs={4} sm={4}>
				 	<Grid style={imageGrid} item xs={12} sm={12}> <img style={imageRuntime} src={Runtime} /> </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '24px'}}> Runtime </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '35px', color: '#008bff'}}> 01:23 Hrs </Grid>
				 </Grid>
				 </RctCollapsibleCard>
				 <RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4"
					reloadable
					fullBlock
					>
				 <Grid style={content} container  xs={4} sm={4}>
				 	<Grid style={imageGrid} item xs={12} sm={12}> <img style={imageRuntime} src={Total} /> </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '24px'}}> Total </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '35px', color: '#008bff'}}> 01:23 Hrs </Grid>
				 </Grid>
				 </RctCollapsibleCard>
				 <RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4"
					reloadable
					fullBlock
					>
				 <Grid style={content} container  xs={4} sm={4}>
				 	<Grid style={imageGrid} item xs={12} sm={12}> <img style={imageRuntime} src={Stops} /> </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '24px'}}> Stops </Grid>
				 	<Grid item xs={12} sm={12} style={{fontSize: '35px', color: '#008bff'}}> 01:23 Hrs </Grid>
				 </Grid>
				 </RctCollapsibleCard>
				 </div>
				 
		);}
}
export default index;