import React, { Component } from 'react'
import Grid from '@material-ui/core/Grid';
import {Link} from 'react-router-dom';
import Assigned from './ChuteStatus/Assigned';
import AssignedPer from './ChuteStatus/AssignedPer';
import NotAssigned from './ChuteStatus/NotAssigned';
import Legends from './ChuteStatus/Legends';
import Doughnut from './ChuteStatus/Doughnut';

import './ChuteStatus/land.css';
import './ChuteStatus/label.css';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

import {baseURL} from '../../services/Config';
import axios from 'axios';

const mainGrid = {
    padding: '15px',
    height: '280px',
};


export default class ChuteStatusOverview extends Component {
    constructor(props) {
		super(props);
		this.state = {  data: [],
						label: ['Full', 'Empty', 'Error', 'Disabled'],
						color: ['#d0021b', '#7ed321', '#f8e71c', '#9f9c9c'],
					    isLoading:true
					  };
	}
	
	async componentWillMount() {
		axios.get(baseURL+'chutesummary/'+ sessionStorage.getItem("username") +this.props.sorterRoute)
			 .then(res => {
			    this.setState({ data: res.data,
                                isLoading:false}); 
			}).catch(function (error) {
				console.log(error);
		  });
    }
    
    render () {
        if(this.state.isLoading) {
			return(<Grid container></Grid>);
		} else {
            return(
				<div className="row">
                <RctCollapsibleCard
				colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full"
				heading={"Chute Status"}
				reloadable
				fullBlock
				>
                    <Grid style={mainGrid} container>	
                        <Grid item xs={12} sm={6}>
                            <Doughnut data={this.state.data} label={this.state.label} color={this.state.color}/>
                        </Grid>
                        <Grid item xs={12} sm={5}>
                            <Legends data={this.state.data}/>
                        </Grid>
                        
                            
                            
                          <div className="right-arrow-chute"><i class="ti-angle-right"></i></div>
								
                    
                    </Grid>
                    
                    <Grid className="chute-bottom-grid" container>
                        <Grid item xs={4} sm={4}>
                            <Assigned value={this.state.data.assigned}/>
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <NotAssigned value={this.state.data.notassigned} />
                        </Grid>
                        <Grid item xs={4} sm={4}>
                            <AssignedPer value={this.state.data.assignedPercentage} />
                        </Grid>
                    </Grid>
            					 

                </RctCollapsibleCard>
				</div>
            )
        }
    }
}